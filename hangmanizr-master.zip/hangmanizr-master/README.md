# Hangmanizr

> Quick Hangman Game

<a href="https://mburakerman.github.io/hangmanizr/"><img src="https://media.giphy.com/media/3o7TKRNtcQkHuPUeKQ/source.gif" /></a>

### License

Licensed under the MIT License.
